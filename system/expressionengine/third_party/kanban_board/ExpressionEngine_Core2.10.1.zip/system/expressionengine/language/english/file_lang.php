<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

'content_files' =>
'Files',

'file_module_name' =>
'File',

'file_module_description' =>
'File module',

//----------------------------------------




''=>''
);

/* End of file file_lang.php */
/* Location: ./system/expressionengine/language/english/file_lang.php */
