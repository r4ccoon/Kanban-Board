<?php

namespace EllisLab\ExpressionEngine\Library\Parser\Conditional\Exception;

class LexerException extends ConditionalException {}
